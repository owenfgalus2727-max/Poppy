(() => {
  if (typeof document === "undefined") {
    console.log("Poppy is ready! Open this script in a browser to use the neon chat app.");
    return;
  }

  const app = document.createElement("main");
  app.className = "app";
  app.innerHTML = `
    <header>
      <div class="orb" aria-hidden="true">✦</div>
      <div><h1>Poppy</h1><div class="status">● online · learning as we chat</div></div>
      <div id="memory-count"></div>
    </header>
    <nav class="tabs" aria-label="Poppy sections">
      <button class="tab active" type="button" data-view="chat-view">Chat</button>
      <button class="tab" type="button" data-view="builder-view">Build a game</button>
      <button class="tab" type="button" data-view="games-view">Game gallery</button>
    </nav>
    <section id="chat-view" class="view active-view">
      <section id="chat" aria-live="polite"></section>
      <div class="composer">
        <p class="hint">Teach Poppy with <b>remember: ...</b> or <b>teach: question =&gt; answer</b></p>
        <form id="form"><input id="input" autocomplete="off" placeholder="Say something to Poppy…" aria-label="Message Poppy"><button class="send-button">Send</button></form>
      </div>
    </section>
    <section id="builder-view" class="view" hidden>
      <div class="section-content">
        <p class="eyebrow">POPPY'S ARCADE WORKSHOP</p>
        <h2>Dream up a mini-game</h2>
        <p class="section-copy">Describe a game idea and Poppy will turn it into a playable starter game. Try “a space game” or “a number guessing game.”</p>
        <form id="builder-form" class="builder-form">
          <label for="game-prompt">Your game idea</label>
          <textarea id="game-prompt" maxlength="180" placeholder="Example: A cozy game about catching stars" required></textarea>
          <label for="game-title">Give it a title</label>
          <input id="game-title" maxlength="40" placeholder="My awesome game" required>
          <button class="build-button" type="submit">✦ Build my game</button>
        </form>
        <p class="note">This demo uses built-in game templates rather than a connected AI. Your games are saved only in this browser.</p>
        <div id="build-result" aria-live="polite"></div>
      </div>
    </section>
    <section id="games-view" class="view" hidden>
      <div class="section-content">
        <p class="eyebrow">MADE WITH POPPY</p>
        <h2>Community game gallery</h2>
        <p class="section-copy">Games you build appear here. In this demo, posts are visible only in this browser.</p>
        <div id="game-gallery" class="game-gallery"></div>
      </div>
    </section>`;
  document.body.appendChild(app);

  const chat = app.querySelector("#chat");
  const input = app.querySelector("#input");
  const memoryCount = app.querySelector("#memory-count");
  const storageKey = "poppy-learning-v1";
  const gamesKey = "poppy-games-v1";
  let memory = { facts: [], lessons: [] };
  let games = [];

  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || "null");
    if (saved && Array.isArray(saved.facts) && Array.isArray(saved.lessons)) memory = saved;
  } catch (_) { /* Continue with temporary memory if storage is unavailable. */ }
  try {
    const savedGames = JSON.parse(localStorage.getItem(gamesKey) || "[]");
    if (Array.isArray(savedGames)) games = savedGames.filter(game => game && typeof game.title === "string" && typeof game.prompt === "string");
  } catch (_) { /* Games remain available for this visit if storage is unavailable. */ }

  function saveMemory() {
    try { localStorage.setItem(storageKey, JSON.stringify(memory)); } catch (_) { /* Storage may be disabled. */ }
    memoryCount.textContent = `${memory.facts.length + memory.lessons.length} learned`;
  }

  function addMessage(text, from) {
    const bubble = document.createElement("div");
    bubble.className = `message ${from}`;
    bubble.textContent = text;
    chat.appendChild(bubble);
    chat.scrollTop = chat.scrollHeight;
  }

  function replyTo(text) {
    const trimmed = text.trim();
    const lower = trimmed.toLowerCase();
    if (lower.startsWith("remember:")) {
      const fact = trimmed.slice(trimmed.indexOf(":") + 1).trim();
      if (!fact) return "Tell me what to remember after “remember:”.";
      if (!memory.facts.some(item => item.toLowerCase() === fact.toLowerCase())) memory.facts.push(fact);
      saveMemory();
      return `Got it! I’ll remember “${fact}” for next time. ✨`;
    }
    if (lower.startsWith("teach:")) {
      const lesson = trimmed.slice(trimmed.indexOf(":") + 1).split("=>");
      if (lesson.length < 2 || !lesson[0].trim() || !lesson.slice(1).join("=>").trim()) return "Try: teach: your question => the answer I should give";
      const question = lesson[0].trim();
      const answer = lesson.slice(1).join("=>").trim();
      const existing = memory.lessons.find(item => item.question.toLowerCase() === question.toLowerCase());
      if (existing) existing.answer = answer;
      else memory.lessons.push({ question, answer });
      saveMemory();
      return `Lesson saved! When you ask “${question}”, I’ll know to say “${answer}”. 💖`;
    }
    const lesson = memory.lessons.find(item => item.question.toLowerCase() === lower);
    if (lesson) return lesson.answer;
    if (/^(hi|hello|hey)\b/.test(lower)) return "Hey! I’m Poppy, your bright little AI buddy. What should we learn today? 🌈";
    if (lower.includes("what do you remember") || lower.includes("what have you learned")) {
      return memory.facts.length ? `Here’s what I’ve learned:\n• ${memory.facts.join("\n• ")}` : "I’m just getting to know you! Teach me with “remember: ...” and I’ll keep it for next time.";
    }
    if (lower.includes("game")) return "Want to make something fun? Open Build a game to create a mini-game, then find it in the Game gallery! 🎮";
    if (memory.facts.length) return `I’m still learning how to answer that. I do remember: ${memory.facts.slice(-3).join("; ")}. You can teach me a reply with “teach: ${trimmed} => your answer”.`;
    return "I’m still learning! Teach me a fact with “remember: ...” or a response with “teach: your question => your answer”. ✨";
  }

  function showView(viewId) {
    app.querySelectorAll(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.view === viewId));
    app.querySelectorAll(".view").forEach(view => {
      const active = view.id === viewId;
      view.hidden = !active;
      view.classList.toggle("active-view", active);
    });
    if (viewId === "games-view") renderGames();
  }

  function makeGameType(prompt) {
    const lower = prompt.toLowerCase();
    if (/guess|number|secret/.test(lower)) return "guess";
    if (/space|star|catch|click|tap|reaction|target/.test(lower)) return "tap";
    return "quiz";
  }

  function buildGame(event) {
    event.preventDefault();
    const prompt = app.querySelector("#game-prompt").value.trim();
    const title = app.querySelector("#game-title").value.trim();
    if (!prompt || !title) return;
    const game = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title, prompt, type: makeGameType(prompt) };
    games.unshift(game);
    try { localStorage.setItem(gamesKey, JSON.stringify(games)); } catch (_) { /* Keep the new game for this visit. */ }
    const result = app.querySelector("#build-result");
    result.textContent = `✨ “${title}” is ready! It’s been added to your Game gallery.`;
    app.querySelector("#builder-form").reset();
    renderGames();
  }

  function createGameCard(game) {
    const card = document.createElement("article");
    card.className = "game-card";
    const title = document.createElement("h3");
    title.textContent = game.title;
    const idea = document.createElement("p");
    idea.className = "game-idea";
    idea.textContent = game.prompt;
    const playArea = document.createElement("div");
    playArea.className = "play-area";
    const playButton = document.createElement("button");
    playButton.className = "play-button";
    playButton.type = "button";
    playButton.textContent = "▶ Play";
    const status = document.createElement("p");
    status.className = "game-status";
    status.setAttribute("aria-live", "polite");
    playButton.addEventListener("click", () => {
      if (game.type === "guess") {
        const answer = Math.floor(Math.random() * 5) + 1;
        const guessInput = document.createElement("input");
        guessInput.type = "number";
        guessInput.min = "1";
        guessInput.max = "5";
        guessInput.placeholder = "1–5";
        guessInput.setAttribute("aria-label", `Guess a number for ${game.title}`);
        const checkButton = document.createElement("button");
        checkButton.type = "button";
        checkButton.className = "mini-button";
        checkButton.textContent = "Guess";
        status.replaceChildren(document.createTextNode("Guess the secret number (1–5): "), guessInput, checkButton);
        checkButton.addEventListener("click", () => {
          const guess = Number(guessInput.value);
          status.textContent = guess === answer ? "You got it! 🎉" : `Not quite—the number was ${answer}. Play again!`;
        });
      } else if (game.type === "tap") {
        let score = 0;
        let remaining = 10;
        const target = document.createElement("button");
        target.type = "button";
        target.className = "mini-button target-button";
        target.textContent = "✦ Tap me!";
        status.replaceChildren(document.createTextNode("Tap the star as many times as you can in 10 seconds! "), target);
        const timer = setInterval(() => {
          remaining -= 1;
          if (remaining <= 0) {
            clearInterval(timer);
            status.textContent = `Time! Your score: ${score} ✨`;
          }
        }, 1000);
        target.addEventListener("click", () => {
          score += 1;
          target.textContent = `✦ ${score}`;
        });
      } else {
        let score = 0;
        const choices = ["🌙", "⭐", "🌈"];
        const answer = "⭐";
        status.textContent = `Quick quiz: which one is the star? `;
        choices.forEach(choice => {
          const choiceButton = document.createElement("button");
          choiceButton.type = "button";
          choiceButton.className = "mini-button choice-button";
          choiceButton.textContent = choice;
          choiceButton.addEventListener("click", () => {
            score += choice === answer ? 1 : 0;
            status.textContent = choice === answer ? `Correct! Score: ${score} ⭐` : `Not that one! The answer was ${answer}.`;
          });
          status.appendChild(choiceButton);
        });
      }
    });
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "remove-button";
    removeButton.textContent = "Remove";
    removeButton.addEventListener("click", () => {
      games = games.filter(item => item.id !== game.id);
      try { localStorage.setItem(gamesKey, JSON.stringify(games)); } catch (_) { /* The game is removed for this visit. */ }
      renderGames();
    });
    playArea.append(playButton, status);
    card.append(title, idea, playArea, removeButton);
    return card;
  }

  function renderGames() {
    const gallery = app.querySelector("#game-gallery");
    gallery.replaceChildren();
    if (!games.length) {
      const empty = document.createElement("p");
      empty.className = "empty-gallery";
      empty.textContent = "No games yet. Head to Build a game and make the first one! ✨";
      gallery.appendChild(empty);
      return;
    }
    games.forEach(game => gallery.appendChild(createGameCard(game)));
  }

  app.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => showView(tab.dataset.view)));
  app.querySelector("#form").addEventListener("submit", event => {
    event.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    addMessage(text, "user");
    input.value = "";
    addMessage(replyTo(text), "bot");
    input.focus();
  });
  app.querySelector("#builder-form").addEventListener("submit", buildGame);
  saveMemory();
  renderGames();
  addMessage("Hi, I’m Poppy! 🌸 I can remember facts, learn replies, and help you make mini-games. My memories stay saved in this browser.", "bot");
})();
